"""Convert the licensed SVG sources to bounded, offline radar primitives.

Regeneration dependency: svg.path==7.1. Firmware reads bounded outlines from the SD catalog.
"""
from pathlib import Path
import json
import re
import hashlib
import zipfile
import xml.etree.ElementTree as ET
from svg.path import parse_path, Move

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'data/aircraft-shapes'


def simplify(points, closed):
    if closed and points[-1] == points[0]:
        points = points[:-1]
    # Remove least significant samples, keeping corners and open endpoints.
    while len(points) > 32:
        choices = range(len(points)) if closed else range(1, len(points)-1)
        def error(i):
            a, p, b = points[i-1], points[i], points[(i+1) % len(points)]
            dx, dy = b[0]-a[0], b[1]-a[1]
            if not dx and not dy:
                return (p[0]-a[0])**2+(p[1]-a[1])**2
            t = max(0, min(1, ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/(dx*dx+dy*dy)))
            return (p[0]-a[0]-t*dx)**2+(p[1]-a[1]-t*dy)**2
        del points[min(choices, key=error)]
    return points


def contours(file):
    paths = []
    def walk(el, translation=0j):
        if 'display:none' in el.get('style', '').replace(' ', ''):
            return
        if el.tag.rsplit('}', 1)[-1] in ('defs', 'metadata', 'namedview'):
            return
        transform = el.get('transform')
        if transform:
            match = re.fullmatch(r'translate\(\s*([-\d.eE]+)[ ,]+([-\d.eE]+)\s*\)', transform)
            if not match:
                raise ValueError('Unsupported visible transform: '+file.name)
            translation += complex(float(match[1]), float(match[2]))
        if el.tag.endswith('}path'):
            points = []
            for seg in parse_path(el.get('d', '')):
                if isinstance(seg, Move):
                    if len(points) > 1:
                        paths.append(points)
                    points = [seg.end+translation]
                    continue
                steps = max(1, min(256, int(seg.length(error=1e-4)*8)+1))
                points.extend(seg.point(i/steps)+translation for i in range(1, steps+1))
            if len(points) > 1:
                paths.append(points)
        for child in el:
            walk(child, translation)
    walk(ET.fromstring(file.read_bytes()))
    if not paths:
        raise ValueError('No visible geometry: '+file.name)
    # B752's source splits its outside edge into two open halves. Join the
    # matching nose/tail endpoints before choosing an exterior contour.
    if file.stem == 'B752':
        major = sorted(paths, key=lambda ps: sum(abs(b-a) for a,b in zip(ps,ps[1:])), reverse=True)[:2]
        if len(major) == 2:
            a,b = major
            possibilities = [(a,b),(a,list(reversed(b))),(list(reversed(a)),b),(list(reversed(a)),list(reversed(b)))]
            a,b = min(possibilities,key=lambda pair:abs(pair[0][-1]-pair[1][0])+abs(pair[1][-1]-pair[0][0]))
            assert abs(a[-1]-b[0]) < 1 and abs(b[-1]-a[0]) < 1
            paths = [a+b+[a[0]]]
    all_points = [p for path in paths for p in path]
    xmin, xmax = min(p.real for p in all_points), max(p.real for p in all_points)
    ymin, ymax = min(p.imag for p in all_points), max(p.imag for p in all_points)
    scale = 196/max(xmax-xmin, ymax-ymin)
    center = complex((xmin+xmax)/2, (ymin+ymax)/2)
    normalized = []
    for path in paths:
        points = []
        for p in path:
            p = (p-center)*scale
            xy = (round(p.real), round(p.imag))
            if not points or xy != points[-1]:
                points.append(xy)
        if len(points) > 1:
            normalized.append((points, abs(path[0]-path[-1]) < .05))
    def area(part):
        ps = part[0]
        return abs(sum(ps[i-1][0]*p[1]-p[0]*ps[i-1][1] for i,p in enumerate(ps)))
    main = max(range(len(normalized)), key=lambda i: area(normalized[i]))
    result = []
    for i, (points, closed) in enumerate(normalized):
        if i != main:
            continue  # Interior accents disappear at radar size; keep the exterior silhouette.
        filled = i == main or closed
        points = simplify(points, filled)
        if len(points) >= (3 if filled else 2):
            result.append((points, 0 if filled else 1))
    return result


def build():
    files = {p.stem: p for p in SOURCE.glob('*.svg') if re.fullmatch('[A-Z0-9]{2,4}', p.stem)}
    # Default low-speed configurations for types with multiple source poses.
    for code in ('B1', 'TOR', 'V22'):
        files[code] = SOURCE/(code+' slow.svg')
    manifest, shapes = [], {}
    for code, file in sorted(files.items()):
        parts = contours(file)
        assert len(parts) == 1
        shapes[code] = [list(p) for p in parts[0][0]]
        manifest.append(dict(icao=code,source=file.name,sha256=hashlib.sha256(file.read_bytes()).hexdigest(),points=len(parts[0][0])))
    OUTPUT = ROOT.parent/'deploy/liveries/aircraft-radar-shapes.json'
    OUTPUT.write_text(json.dumps(shapes,sort_keys=True,separators=(',',':'))+'\n',encoding='utf-8')
    (SOURCE/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    archive = ROOT.parent/'deploy/liveries/aircraft-shapes-source.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        inputs = [(p.name,p.read_bytes()) for p in sorted(SOURCE.iterdir()) if p.is_file()]
        inputs += [('build_aircraft_shapes.py',Path(__file__).read_bytes()),('aircraft-radar-shapes.json',OUTPUT.read_bytes())]
        for name,data in inputs:
            info=zipfile.ZipInfo(name,(2026,10,14,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
    print('Generated',len(files),'ICAO symbols;',OUTPUT.stat().st_size,'JSON bytes')


if __name__ == '__main__':
    build()
