"""Prepare six simplified radar contours. GPL-3.0; see NOTICE and LICENSE.

Family construction follows the existing A19N/E195/AT75 SVG vocabulary.
Overall length/span are factual dimensions; minor features are radar-scale
approximations, not manufacturer CAD or variant-identification evidence.
"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
AIRBUS='https://aircraft.airbus.com/sites/g/files/jlcbta126/files/2023-12/ac_a319_1223.pdf'
E190='https://www.gov.br/anac/pt-br/assuntos/regulados/aeronaves/avaliacao-operacional/RelAvOp_ERJ170_190.pdf'
E2='https://www.embraer.com/media/vmsjxvk5/e-jets-e2_apm_e-jetse2.pdf'
E295=E2
ATR='https://www.atr-aircraft.com/wp-content/uploads/2020/07/Factsheets_-_ATR_72-600.pdf'
SPECS={
 'A319':dict(length=33.84,span=34.10,base='A19N.svg',reference=AIRBUS,variant='A319ceo with wing-tip fences'),
 'E190':dict(length=36.24,span=28.72,base='E195.svg',reference=E190),
 'E290':dict(length=36.24,span=33.72,base='E195.svg',reference=E2),
 'E295':dict(length=41.60,span=35.12,base='E195.svg',reference=E295),
 'AT72':dict(length=27.166,span=27.050,base='AT75.svg',reference=ATR,note='Shared simplified ATR72 exterior; propeller blade count is not encoded.'),
 'AT76':dict(length=27.166,span=27.050,base='AT75.svg',reference=ATR,note='Shared simplified ATR72 exterior; propeller blade count is not encoded.')}
def jet(length,span,width,engine_center,engine_width,tail_span,e2=False):
 # One exterior ring, symmetric around the longitudinal axis. Each side has
 # a nose shoulder, nacelle, swept wing and horizontal stabilizer.
 f=width/2;c=engine_center;n=engine_width/2;l=length
 side=[(.55*f,-.47*l),(f,-.41*l),(f,-.16*l),
       (c-n,-.125*l),(c-n,-.215*l),(c+n,-.215*l),(c+n,-.105*l),
       (.5*span,.10*l if e2 else .065*l),(.49*span,.125*l if e2 else .105*l),
       (1.15*f,.045*l),(.62*f,.365*l),(.5*tail_span,.445*l),(.5*tail_span,.48*l),(.30*f,.45*l)]
 return [(0,-l/2)]+side+[(0,l/2)]+[(-x,y) for x,y in reversed(side)]
def turboprop(length,span):
 l=length;f=1.3
 side=[(.55*f,-.47*l),(f,-.41*l),(f,-.14*l),(3.55,-.12*l),
       (3.55,-.20*l),(4.05,-.23*l),(4.7,-.12*l),(.48*span,-.10*l),
       (.5*span,-.035*l),(1.1*f,0),(.85*f,.28*l),(.35*f,.405*l),
       (.145*span,.43*l),(.145*span,.475*l),(.2*f,.46*l)]
 return [(0,-l/2)]+side+[(0,l/2)]+[(-x,y) for x,y in reversed(side)]
def build():
 records={}
 for code,s in SPECS.items():
  l,span=s['length'],s['span']
  if code.startswith('AT'):points=turboprop(l,span)
  elif code=='A319':points=jet(l,span,3.95,5.4,1.9,12.4)
  else:points=jet(l,span,3.01,4.25,2.15 if code!='E190' else 1.55,10.8,e2=code!='E190')
  assert len(points)<=32
  scale=196/max(l,span);points=[(round(x*scale,4),round(y*scale,4)) for x,y in points]
  path='M '+' L '.join(f'{x},{y}' for x,y in points)+' Z'
  xml=f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="-100 -100 200 200">
<title>{code} — simplified PlaneSlate radar contour</title>
<desc>GPL-3.0. Derived family geometry: {s['base']}. Dimensions and limitations: derived-contours.json. Prepared 2026-10-21; not manufacturer CAD.</desc>
<path fill="#ffffff" d="{path}"/>
</svg>
'''
  p=ROOT/(code+'.svg');p.write_text(xml,encoding='utf8',newline='\n')
  records[code]={**s,'base_sha256':hashlib.sha256((ROOT/s['base']).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'simplified_vertices':len(points),'status':'user_approved_2026_10_21'}
 (ROOT/'derived-contours.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8')
 print('Prepared six local SVG candidates, maximum 32 points each.')
if __name__=='__main__':build()
